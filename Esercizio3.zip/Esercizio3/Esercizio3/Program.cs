﻿using System;


namespace Media_età_persone
{
    class Media_età_persone
    {
        //attributi
        double eta1;
        double eta2;
        double eta3;
        bool conversione1;
        bool conversione2;
        bool conversione3;
        double media;

        //metodo di default
        public Media_età_persone()
        {
            eta1 = 0;
            eta2 = 0;
            eta3 = 0;
        }

        //metodi
        public void inserisciEta()
        {
            do      //ciclo per avere la possibilità di riscrivere un valore se lo si sbaglia
            {
                Console.WriteLine("Inserisci l'età della prima persona");       //inserisco età della persona
                string e = Convert.ToString(Console.ReadLine());
                conversione1 = double.TryParse(e, out eta1);
            } while (!conversione1);

            do      //ciclo per avere la possibilità di riscrivere un valore se lo si sbaglia
            {
                Console.WriteLine("Inserisci l'età della seconda persona");     //inserisco età della persona
                string e = Convert.ToString(Console.ReadLine());
                conversione2 = double.TryParse(e, out eta2);
            } while (!conversione2);

            do      //ciclo per avere la possibilità di riscrivere un valore se lo si sbaglia
            {
                Console.WriteLine("Inserisci l'età della terza persona");       //inserisco età della persona
                string e = Convert.ToString(Console.ReadLine());
                conversione3 = double.TryParse(e, out eta3);
            } while (!conversione3);
        }
        public void mediaEta()
        {
            media = (eta1 + eta2 + eta3) / 3;
            Console.WriteLine("La media delle età è: {0}", media);      //calcolo la media delle età
        }
        static void Main(string[] args)
        {
            Media_età_persone c = new Media_età_persone();
            c.inserisciEta();
            c.mediaEta();
            Console.ReadKey();
        }
    }
}