﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conto_Corrente
{
    class Program
    {
        class ContoCorrente
        {
            protected double saldo;
            public ContoCorrente()
            {
                saldo = 500;
            }
            public override string ToString()
            {
                return $"Il tuo saldo iniziale è di {saldo}";
            }
        }

        class ContoMod : ContoCorrente
        {
            //protected double prel;
            //protected double vers;
            public double prelievo(double prel)
            {
                saldo -= prel;
                return saldo;
            }
            public double versamento(double vers)
            {
                saldo += vers;
                return saldo;
            }
        }


        static void Main(string[] args)
        {
            ContoCorrente c = new ContoCorrente();
            int scelta;
            Console.WriteLine($"{c.ToString()}");
            ContoMod m = new ContoMod();
            do
            {              
                Console.WriteLine("Premi 1 per versare o 2 per prelevare o 3 per uscire");
                scelta = Convert.ToInt32(Console.ReadLine());
                switch (scelta)
                {
                    case 1:
                        Console.Clear();
                        double vers;
                        bool controllo;
                        do
                        {
                            Console.WriteLine("Inserisci la somma da versare, deve essere minore di 3000");
                            string p = Convert.ToString(Console.ReadLine());
                            controllo = double.TryParse(p, out vers);
                        } while (!controllo || vers < 0 || vers > 3000);
                        Console.WriteLine($"Il tuo saldo dopo il versamento è di {m.versamento(vers)}");
                        break;
                    case 2:
                        Console.Clear();
                        double prel;
                        bool controllo2;
                        do
                        {
                            Console.WriteLine("Inserisci la somma da prelevare, deve essere minore di 3000");
                            string p = Convert.ToString(Console.ReadLine());
                            controllo2 = double.TryParse(p, out prel);
                        } while (!controllo2 || prel < 0 || prel > 3000);
                        Console.WriteLine($"Il tuo saldo dopo il prelievo è di {m.prelievo(prel)}");
                        break;
                    case 3:
                        Environment.Exit(1);
                        break;
                    default:
                        break;
                }
            } while (scelta != 3);
            Console.ReadKey();
        }
    }
}
