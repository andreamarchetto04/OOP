﻿/*Tramite la programmazione ad oggetti scrivere un programma in c# che dopo aver costruito la classe Calciatore visualizzi in output
 * il nome del calciatore, il ruolo, la squadra ed i gol segnati (i dati vengono assegnati all'interno del codice) */

using System;   //istruzione per l'utilizzo della libreria system che permette di usare alcune classi console e i metodi write e readline

namespace Calciatore    //parola chiave per dichiarare un ambito che contiene un set di oggetti correlati
{
    class Calciatore    //definizione della classe pagina 20
    {
        //attributi
        string nome;
        string squadra;
        string ruolo;
        int golSegnati;

        //metodo di default: costruttore
        public Calciatore()
        {
            //this.nome = nome;   //La parola chiave "this" serve per inizializzare i campi membro (attributi)
            //this.squadra = squadra;
            //this.ruolo = ruolo;
            golSegnati = 0;
        }

        //metodi       
        public void visualizzaDati()
        {
            Console.WriteLine("Il giocatore '{0}' è un {2} che ha segnato {1} gol e gioca nella squadra {3}", nome, golSegnati, ruolo, squadra);
        }
        public void letturaDati()
        {
            Console.WriteLine("Inserisci il nome del calciatore");
            nome = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Inserisci il nome della squadra in cui gioca");
            squadra = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Inserisci il ruolo del calciatore");
            ruolo = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Inserisci il numero di gol");
            golSegnati = Convert.ToInt32(Console.ReadLine());
        }

        static void Main(string[] args)
        {
            Calciatore c = new Calciatore();
            c.letturaDati();
            c.visualizzaDati();
            Console.ReadKey();

        }
    }
}
