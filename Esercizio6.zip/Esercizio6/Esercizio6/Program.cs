﻿//Dopo aver acquisito da tastiera una serie di prezzi relativi ai cellulari in vendita in un negozio,
//scrivere il codice di un programma(OOP) in C# che visualizzi i prezzi maggiori di 100€.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prezzi_Cellulari
{
    class Prezzi_Cellulari
    {
        //attributi
        double[] prezziCell;
        int nPrezzi;
        int i;
        bool conversione1;
        bool conversione2;

        //metodo di default
        public Prezzi_Cellulari()
        {
            nPrezzi = 0;
            i = 0;
            prezziCell = new double[0];
        }

        //metodi
        public void inserisciPrezzi()
        {
            do          //ciclo per fare in modo che se inserisco valori che non sono numeri mi chieda di reinserirli
            {
                Console.WriteLine("Inserisci numero dei prezzi riscontrati"); //inserisco il numero di prezzi
                string e = Convert.ToString(Console.ReadLine());                    //che determina la grandezza dell'array
                conversione2 = int.TryParse(e, out nPrezzi);
            } while (!conversione2);

            prezziCell = new double[nPrezzi];

            for (i = 0; i < nPrezzi; i++)
            {
                do          //ciclo per fare in modo che se inserisco valori che non sono numeri mi chieda di reinserirli
                {
                    Console.WriteLine("Inserisci il prezzo in posizione {0}", i);  //inserisco i prezzi
                    string e = Convert.ToString(Console.ReadLine());
                    conversione1 = double.TryParse(e, out prezziCell[i]);
                } while (!conversione1);
            }
            i = 0;
        }
        public void outValoriMaggiori()
        {
            Console.WriteLine("Questi sono i prezzi maggiori di 100");      //stampo i prezzi maggiori di 100
            for (i = 1; i < nPrezzi; i++)
            {
                if (prezziCell[i] > 100)
                {
                    Console.WriteLine(prezziCell[i]);
                }
            }
            i = 0;
        }
        static void Main(string[] args)
        {
            Prezzi_Cellulari c = new Prezzi_Cellulari();
            c.inserisciPrezzi();
            c.outValoriMaggiori();
            Console.ReadKey();
        }
    }
}
