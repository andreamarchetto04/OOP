﻿//Tramite la programmazione ad oggetti scrivere un programma in C# che dopo aver lettto in input il raggio di una circonferenza, calcoli
// e visualizzi in output la misura del diametro(2*r), della circonferenza(2*r*pi) e la sua area(r2*pi). (Utilizzare la funzione Math.PI)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcolo_Circonferenza
{
    class Calcolo_Circonferenza
    {
        //attributi
        double raggio;
        double diametro;
        double crf;
        double area;
        bool conversione1;

        //metodo di default
        public Calcolo_Circonferenza()
        {
            raggio = 0;
        }

        //metodi
        public void inserisciRaggio()
        {
            do
            {
                Console.WriteLine("Inserisci il raggio della circonferenza");   //inserisco la misura del raggio
                string e = Convert.ToString(Console.ReadLine());                //acendo in modo che il valore inserito vada bene
                conversione1 = double.TryParse(e, out raggio);
            } while (!conversione1);
        }
        public void calcoloDiametro()
        {
            diametro = 2 * raggio;  //calcolo diametro
        }
        public void calcoloCrf()
        {
            crf = 2 * raggio * Math.PI; //calcolo la misura della circonferenza
        }
        public void calcoloArea()
        {
            area = Math.Sqrt(raggio) * Math.PI; //calcolo l'area
        }
        public void visualizzaValori()
        {   //stampo i valori delle richieste
            Console.WriteLine("La circonferenza di raggio {0} ha diametro di {1}, misura {2} e la sua area è {3}", raggio, diametro, crf, area);
        }
        static void Main(string[] args)
        {
            Calcolo_Circonferenza c = new Calcolo_Circonferenza();
            c.inserisciRaggio();
            c.calcoloDiametro();
            c.calcoloCrf();
            c.calcoloArea();
            c.visualizzaValori();
            Console.ReadKey();
        }
    }
}
