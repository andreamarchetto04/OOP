﻿//Dopo aver acquisito da tastiera una serie di dati relativi alla misurazione della temperatura di una certa città, scrivere
// il codice di un programma(OOP) in C# che determini e visualizzi la temperatura più bassa e quella più alta.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temperature
{
    class Temperature
    {
        //attributi
        double[] temperature;
        int nTemp;
        double tempMax;
        double tempMin;
        int i;
        bool conversione1;
        bool conversione2;


        //metodo di default
        public Temperature()
        {
            nTemp = 0;
            i = 0;
            temperature = new double[0];
        }

        //metodi
        public void inserisciTemp()
        {
            do
            {
                Console.WriteLine("Inserisci numero delle misurazioni effettuate"); //inserisco il numero di misurazioni
                string e = Convert.ToString(Console.ReadLine());                    //che determina la grandezza dell'array
                conversione2 = int.TryParse(e, out nTemp);
            } while (!conversione2);

            temperature = new double[nTemp];

            for (i = 0; i < nTemp; i++)
            {
                do
                {
                    Console.WriteLine("Inserisci la temperatura in posizione {0}", i);  //inserisco le temperature misurate
                    string e = Convert.ToString(Console.ReadLine());
                    conversione1 = double.TryParse(e, out temperature[i]);
                } while (!conversione1);

            }
            i = 0;
        }
        public void calcoloTempMax()
        {

            tempMax = temperature[0];   //inizializzo la temperatura massima come la prima inserita

            for (i = 1; i < nTemp; i++)
            {
                if (temperature[i] > tempMax)
                {
                    tempMax = temperature[i];   //definisco la temperatura massima confontandola con le successive misure
                }
            }
            i = 0;
        }
        public void calcoloTempMin()
        {

            tempMin = temperature[0];   //inizializzo la temperatura minima come la prima inserita

            for (i = 1; i < nTemp; i++)
            {
                if (temperature[i] < tempMin)   //definisco la temperatura minima confontandola con le successive misure
                {
                    tempMin = temperature[i];
                }
            }
            i = 0;
        }
        public void visualizzaValori()
        {   //stampo i valori trovati
            Console.WriteLine("La temperatura più alta registrata è di {0} gradi, mentre la più bassa è di {1} gradi", tempMax, tempMin);
        }

        static void Main(string[] args)
        {
            Temperature c = new Temperature();
            c.inserisciTemp();
            c.calcoloTempMax();
            c.calcoloTempMin();
            c.visualizzaValori();
            Console.ReadKey();
        }
    }
}
